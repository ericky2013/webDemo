Picker
======

A jQuery plugin for replacing default checkboxes and radios. Part of the formstone library.

[Documentation and Examples](http://www.benplum.com/formstone/picker/)

Bower Support: `bower install Picker`
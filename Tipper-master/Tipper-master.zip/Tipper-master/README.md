Tipper
========

A jQuery plugin for attaching custom tooltips to elements. Part of the formstone library.

[Documentation and Examples](http://www.benplum.com/formstone/tipper/)

Bower Support: `bower install Tipper`
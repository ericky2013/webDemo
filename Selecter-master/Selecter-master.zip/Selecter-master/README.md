<a href="http://gruntjs.com" target="_blank"><img src="https://cdn.gruntjs.com/builtwith.png" alt="Built with Grunt"></a>
# Selecter

A jQuery plugin for replacing default select elements. Part of the formstone library.

- [Demo](http://www.benplum.com/components/Selecter/demo/index.html)
- [Documentation](http://www.benplum.com/formstone/selecter/)

#### Bower Support

`bower install Selecter`
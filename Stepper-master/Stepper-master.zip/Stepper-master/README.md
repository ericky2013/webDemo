Stepper
=======

A jQuery plugin for cross browser number inputs. Part of the formstone library.

[Documentation and Examples](http://www.benplum.com/projects/stepper/)

Bower Support: `bower install Stepper`